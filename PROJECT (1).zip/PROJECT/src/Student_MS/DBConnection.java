package Student_MS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    public static Connection connect(){
        Connection con = null;
        String username = "root";
        String password = "";
        String dataCon = "jdbc:mysql://localhost:3306/project";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dataCon,username,password);
            
        }
        catch(ClassNotFoundException | SQLException e){
            System.out.println("The problem is "+e);
        }
        return con;
    }
}