package Student_MS;
//Import  all libraries
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

//create class Student_MS
public class Student_MS extends javax.swing.JFrame {

    Connection sqlCon =null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    
    int q, i;
    
    //Constructore of class
    public Student_MS() {
        initComponents();
        sqlCon = DBConnection.connect();
        jTableDB.setAutoResizeMode(jTableDB.AUTO_RESIZE_OFF);
    }
    
    @SuppressWarnings("unchecked")
    
    public void uploadDBtable()
    {
        try
        {
            DBConnection.connect();
            pst = sqlCon.prepareStatement("select * from stdb");
            rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q =stData.getColumnCount();
            
            DefaultTableModel studentRecord = (DefaultTableModel)jTableDB.getModel();
            studentRecord.setRowCount(0);
            
            while(rs.next())
            {
                Vector columnData = new Vector();
                
                for(i= 0; i<=q; i++)
                {
                    columnData.add(rs.getString("StudentID"));
                    columnData.add(rs.getString("Firstname"));
                    columnData.add(rs.getString("Surname"));
                    columnData.add(rs.getString("Address"));
                    columnData.add(rs.getString("Gender"));
                    columnData.add(rs.getString("Age"));
                    columnData.add(rs.getString("PhoneNumber"));
                    columnData.add(rs.getString("Email"));
                    
                    columnData.add(rs.getString("Degre"));
                    columnData.add(rs.getString("HomeStudent"));
                    columnData.add(rs.getString("Accommodation"));
                    columnData.add(rs.getString("Exchange"));
                    columnData.add(rs.getString("Scholarship"));
                    
                   
                    columnData.add(rs.getString("BSc"));
                    columnData.add(rs.getString("MSc"));

                    columnData.add(rs.getString("Class1"));
                    columnData.add(rs.getString("Score1"));
                    columnData.add(rs.getString("Class2"));
                    columnData.add(rs.getString("Score2"));
                    columnData.add(rs.getString("Class3"));
                    columnData.add(rs.getString("Score3"));
                    columnData.add(rs.getString("Class4"));
                    columnData.add(rs.getString("Score4"));
                    columnData.add(rs.getString("Class5"));
                    columnData.add(rs.getString("Score5"));
                    
                    columnData.add(rs.getString("TotalScore"));
                    columnData.add(rs.getString("Ranking"));
                    columnData.add(rs.getString("Date"));
                }
                studentRecord.addRow(columnData);
            }  
        }
        catch(Exception ex)
        {
        JOptionPane.showMessageDialog(null, ex);
    }
    }

    //@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabSelect = new javax.swing.JTabbedPane();
        jPanMain = new javax.swing.JPanel();
        jPanTitle = new javax.swing.JPanel();
        jLTitle2 = new javax.swing.JLabel();
        jLMyName = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanStudent = new javax.swing.JPanel();
        jLStdID = new javax.swing.JLabel();
        jtxtStudentID = new javax.swing.JTextField();
        jLFname = new javax.swing.JLabel();
        jtxtFirstname = new javax.swing.JTextField();
        jLSname = new javax.swing.JLabel();
        jtxtSurname = new javax.swing.JTextField();
        jLAddr = new javax.swing.JLabel();
        jtxtAddress = new javax.swing.JTextField();
        jLGen = new javax.swing.JLabel();
        jcboGender = new javax.swing.JComboBox<>();
        jLAge = new javax.swing.JLabel();
        jtxtAge = new javax.swing.JTextField();
        jLPh_num = new javax.swing.JLabel();
        jtxtPhoneNumber = new javax.swing.JTextField();
        jLEmail = new javax.swing.JLabel();
        jtxtEmail = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jcboHS = new javax.swing.JComboBox<>();
        jcboExchange = new javax.swing.JComboBox<>();
        jcboAccom = new javax.swing.JComboBox<>();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanDegre = new javax.swing.JPanel();
        jcboDegre = new javax.swing.JComboBox<>();
        jtxtHoD = new javax.swing.JTextField();
        jtxtDeputyDean = new javax.swing.JTextField();
        jtxtDoF = new javax.swing.JTextField();
        jtxtFacultyName = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jcboMSc = new javax.swing.JComboBox<>();
        jLabel31 = new javax.swing.JLabel();
        jcboBSc = new javax.swing.JComboBox<>();
        jLabel24 = new javax.swing.JLabel();
        jcboScholarship = new javax.swing.JComboBox<>();
        jPanCla_Sco = new javax.swing.JPanel();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jcboClass3 = new javax.swing.JComboBox<>();
        jtxtScore1 = new javax.swing.JTextField();
        jcboClass4 = new javax.swing.JComboBox<>();
        jcboClass5 = new javax.swing.JComboBox<>();
        jcboClass1 = new javax.swing.JComboBox<>();
        jcboClass2 = new javax.swing.JComboBox<>();
        jtxtScore2 = new javax.swing.JTextField();
        jtxtScore3 = new javax.swing.JTextField();
        jtxtScore4 = new javax.swing.JTextField();
        jtxtTotalScore = new javax.swing.JTextField();
        jtxtScore5 = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jtxtDate = new javax.swing.JTextField();
        jtxtRanking = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jPanButtons = new javax.swing.JPanel();
        jbAdd = new javax.swing.JButton();
        jbReset = new javax.swing.JButton();
        jbResult = new javax.swing.JButton();
        jbExit = new javax.swing.JButton();
        jPanDB = new javax.swing.JPanel();
        jPanTitle1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLTitle3 = new javax.swing.JLabel();
        jPanTableDB = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableDB = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Student Management System");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabSelect.setBackground(new java.awt.Color(255, 103, 103));

        jPanMain.setBackground(new java.awt.Color(255, 75, 75));
        jPanMain.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanTitle.setBackground(new java.awt.Color(255, 104, 74));
        jPanTitle.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanTitle.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLTitle2.setFont(new java.awt.Font("Times New Roman", 1, 8)); // NOI18N
        jLTitle2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLTitle2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Student_MS/logo.png"))); // NOI18N
        jPanTitle.add(jLTitle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 180, 70));

        jLMyName.setFont(new java.awt.Font("Times New Roman", 3, 20)); // NOI18N
        jLMyName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLMyName.setText("Worked by Ana Vokopola");
        jPanTitle.add(jLMyName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 50, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 60)); // NOI18N
        jLabel2.setText("Canadian Institute of Technology");
        jPanTitle.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, -1, -1));

        jPanMain.add(jPanTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 1340, 90));

        jPanStudent.setBackground(new java.awt.Color(255, 104, 74));
        jPanStudent.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanStudent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLStdID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLStdID.setText("Student ID");
        jPanStudent.add(jLStdID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jtxtStudentID.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtStudentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 250, 30));

        jLFname.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLFname.setText("Firstname");
        jPanStudent.add(jLFname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jtxtFirstname.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtFirstname, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 250, 30));

        jLSname.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLSname.setText("Surname");
        jPanStudent.add(jLSname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jtxtSurname.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtSurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 250, 30));

        jLAddr.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLAddr.setText("Address");
        jPanStudent.add(jLAddr, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jtxtAddress.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 250, 30));

        jLGen.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLGen.setText("Gender");
        jPanStudent.add(jLGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jcboGender.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jcboGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Female", "Male" }));
        jPanStudent.add(jcboGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 250, 30));

        jLAge.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLAge.setText("Age");
        jPanStudent.add(jLAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, -1));

        jtxtAge.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, 250, 30));

        jLPh_num.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLPh_num.setText("Phone number");
        jPanStudent.add(jLPh_num, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        jtxtPhoneNumber.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtPhoneNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 250, 30));

        jLEmail.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLEmail.setText("Email");
        jPanStudent.add(jLEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));

        jtxtEmail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanStudent.add(jtxtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 250, 30));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel28.setText("Home Student");
        jPanStudent.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        jcboHS.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcboHS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "No", "Yes" }));
        jPanStudent.add(jcboHS, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, 250, 30));

        jcboExchange.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcboExchange.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "No", "Yes" }));
        jPanStudent.add(jcboExchange, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 250, 30));

        jcboAccom.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcboAccom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Home", "No", "Yes" }));
        jPanStudent.add(jcboAccom, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 420, 250, 30));

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel25.setText("Exchange");
        jPanStudent.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 100, -1));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel26.setText("Accommodation");
        jPanStudent.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        jPanMain.add(jPanStudent, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 470, 480));

        jPanDegre.setBackground(new java.awt.Color(255, 104, 74));
        jPanDegre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanDegre.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jcboDegre.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jcboDegre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select a Degre", "Software Engineering", "Computer Engineering & IT", "Telecommunication Engineering", "Business Administration", "Business Administration & IT", "Finance & Accounting" }));
        jcboDegre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcboDegreActionPerformed(evt);
            }
        });
        jPanDegre.add(jcboDegre, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 250, 30));

        jtxtHoD.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanDegre.add(jtxtHoD, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 260, 250, 30));

        jtxtDeputyDean.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanDegre.add(jtxtDeputyDean, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 250, 30));

        jtxtDoF.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanDegre.add(jtxtDoF, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 180, 250, 30));

        jtxtFacultyName.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanDegre.add(jtxtFacultyName, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 250, 30));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel12.setText("Head of Department");
        jPanDegre.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 170, -1));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel13.setText("Deputy Dean");
        jPanDegre.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 170, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel14.setText("Dean of Faculty");
        jPanDegre.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 170, -1));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel15.setText("Faculty Name");
        jPanDegre.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 170, -1));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel17.setText("Degre");
        jPanDegre.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 170, -1));

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel32.setText("MSc");
        jPanDegre.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 170, -1));

        jcboMSc.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcboMSc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1.1", "1.2", "2.1", "2.2" }));
        jPanDegre.add(jcboMSc, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 250, 30));

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel31.setText("BSc");
        jPanDegre.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 170, -1));

        jcboBSc.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcboBSc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1.1", "1.2", "2.1", "2.2", "3.1", "3.2" }));
        jPanDegre.add(jcboBSc, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 250, 30));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel24.setText("Scholarship");
        jPanDegre.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, -1, -1));

        jcboScholarship.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jcboScholarship.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "No", "Yes" }));
        jPanDegre.add(jcboScholarship, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, 250, 30));

        jPanMain.add(jPanDegre, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 110, 470, 350));

        jPanCla_Sco.setBackground(new java.awt.Color(255, 104, 74));
        jPanCla_Sco.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanCla_Sco.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanCla_Sco.add(jCalendar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 360, 170));

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("2");
        jLabel34.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanCla_Sco.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 20, -1));

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel35.setText("No");
        jPanCla_Sco.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel36.setText("Score");
        jPanCla_Sco.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 190, -1, -1));

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("3");
        jLabel38.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanCla_Sco.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 20, -1));

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("4");
        jLabel39.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanCla_Sco.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 20, -1));

        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("5");
        jLabel40.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanCla_Sco.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 20, -1));

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setText("1");
        jLabel42.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanCla_Sco.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 20, 24));

        jcboClass3.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcboClass3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Computer Applications", "Language - Microprocessor Systems", "Computer Science Fundamentals", "Web Design", "Java Programming", "Pattern Recognition", "Web Engineering", "Financial Reporting Standards", "Organizational Behavior", "" }));
        jcboClass3.setMinimumSize(new java.awt.Dimension(82, 23));
        jcboClass3.setPreferredSize(new java.awt.Dimension(82, 23));
        jcboClass3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcboClass3ActionPerformed(evt);
            }
        });
        jPanCla_Sco.add(jcboClass3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, 220, 24));

        jtxtScore1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtScore1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, 90, 24));

        jcboClass4.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcboClass4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Calculus", "E-commerce and Innovation", "Engineering Chemistry", "Operating Systems", "User Interface Design", "Data Mining", "Digital Design", "Macroeconomics", "Auditing", "Economic Environment", "Planning and Control Systems", "Innovation Management" }));
        jcboClass4.setMinimumSize(new java.awt.Dimension(82, 23));
        jcboClass4.setPreferredSize(new java.awt.Dimension(82, 23));
        jcboClass4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcboClass4ActionPerformed(evt);
            }
        });
        jPanCla_Sco.add(jcboClass4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, 220, 24));

        jcboClass5.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcboClass5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Research Methods", "Electric Circuits", "Engineering Simulations", "Photonics", "Project Management", "Network Programming", "Machine Learning", "Legal Environment", "Communication Skills", "Managerial Finance", "Entrepreneurship Management" }));
        jcboClass5.setMinimumSize(new java.awt.Dimension(82, 23));
        jcboClass5.setPreferredSize(new java.awt.Dimension(82, 23));
        jcboClass5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcboClass5ActionPerformed(evt);
            }
        });
        jPanCla_Sco.add(jcboClass5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 340, 220, 24));

        jcboClass1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcboClass1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Academic Reading and Writing", "Physics", "Computer Communications and Networks", "Digital Logic", "Signals and Systems", "Database Design", "Data Analytics", "Finance Accounting", "Marketing", "Microeconomics", "Managerial Economics", "Marketing Management" }));
        jcboClass1.setMinimumSize(new java.awt.Dimension(82, 23));
        jcboClass1.setPreferredSize(new java.awt.Dimension(82, 23));
        jcboClass1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcboClass1ActionPerformed(evt);
            }
        });
        jPanCla_Sco.add(jcboClass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 220, 24));

        jcboClass2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcboClass2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Economics", "Computer Architecture and Assembly", "Statistics", "Database Systems", "Embedded Systems", "Database Administration", "Data Science", "Managerial Accounting", "HR Management", "Finance", "Managerial Accounting", "International Marketing" }));
        jcboClass2.setMinimumSize(new java.awt.Dimension(82, 23));
        jcboClass2.setPreferredSize(new java.awt.Dimension(82, 23));
        jcboClass2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcboClass2ActionPerformed(evt);
            }
        });
        jPanCla_Sco.add(jcboClass2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 220, 24));

        jtxtScore2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtScore2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 90, 24));

        jtxtScore3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtScore3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, 90, 24));

        jtxtScore4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtScore4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 90, 24));

        jtxtTotalScore.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtTotalScore, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 380, 180, 24));

        jtxtScore5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtScore5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 340, 90, 24));

        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel45.setText("Date");
        jPanCla_Sco.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, -1, -1));

        jLabel46.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel46.setText("Total Score");
        jPanCla_Sco.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, -1, -1));

        jLabel47.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel47.setText("Ranking");
        jPanCla_Sco.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, -1, -1));

        jtxtDate.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 440, 180, 24));

        jtxtRanking.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanCla_Sco.add(jtxtRanking, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 410, 180, 24));

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel37.setText("Class Selector");
        jPanCla_Sco.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, -1, -1));

        jPanMain.add(jPanCla_Sco, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 110, 380, 480));

        jPanButtons.setBackground(new java.awt.Color(255, 104, 74));
        jPanButtons.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanButtons.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbAdd.setBackground(new java.awt.Color(0, 153, 51));
        jbAdd.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jbAdd.setText("Add");
        jbAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAddActionPerformed(evt);
            }
        });
        jPanButtons.add(jbAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 210, 50));

        jbReset.setBackground(new java.awt.Color(255, 255, 0));
        jbReset.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jbReset.setText("Reset");
        jbReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbResetActionPerformed(evt);
            }
        });
        jPanButtons.add(jbReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 210, 50));

        jbResult.setBackground(new java.awt.Color(0, 255, 255));
        jbResult.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jbResult.setText("Result");
        jbResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbResultActionPerformed(evt);
            }
        });
        jPanButtons.add(jbResult, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 200, 50));

        jbExit.setBackground(new java.awt.Color(255, 0, 0));
        jbExit.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jbExit.setText("Exit");
        jbExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbExitActionPerformed(evt);
            }
        });
        jPanButtons.add(jbExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, 200, 50));

        jPanMain.add(jPanButtons, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 470, 470, 120));

        jTabSelect.addTab("Registration Window", jPanMain);

        jPanDB.setBackground(new java.awt.Color(255, 75, 75));
        jPanDB.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanTitle1.setBackground(new java.awt.Color(255, 104, 74));
        jPanTitle1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanTitle1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 60)); // NOI18N
        jLabel1.setText("Canadian Institute of Technology");
        jPanTitle1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        jLTitle3.setFont(new java.awt.Font("Times New Roman", 1, 8)); // NOI18N
        jLTitle3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLTitle3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Student_MS/logo.png"))); // NOI18N
        jPanTitle1.add(jLTitle3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 180, 70));

        jPanDB.add(jPanTitle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1360, 90));

        jPanTableDB.setBackground(new java.awt.Color(255, 104, 74));
        jPanTableDB.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(186, 25, 28), 8));
        jPanTableDB.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTableDB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "StudentID", "Firstname", "Surname", "Address", "Gender", "Age", "PhoneNumber", "Email", "Degre", "HomeStudent", "Accommodation", "Exchange", "Scholorship", "BSc", "MSc", "Class 1", "Score 1", "Class 2", "Score 2", "Class 3", "Score 3", "Class 4", "Score 4", "Class 5", "Score 5", "TotalScore", "Ranking", "Date"
            }
        ));
        jScrollPane1.setViewportView(jTableDB);

        jPanTableDB.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1340, 460));

        jPanDB.add(jPanTableDB, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 1360, 480));

        jTabSelect.addTab("Students Details", jPanDB);

        getContentPane().add(jTabSelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1380, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
       uploadDBtable();
    }//GEN-LAST:event_formWindowActivated
private JFrame frame;
    private void jbExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbExitActionPerformed
        frame = new JFrame ("Exit");
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","CIT Student Management System",
            JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION){
        System.exit(0);
        }
    }//GEN-LAST:event_jbExitActionPerformed

    private void jbResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbResultActionPerformed

        int[] marks = new int[6];

        marks[0] = Integer.parseInt(jtxtScore1.getText());
        marks[1] = Integer.parseInt(jtxtScore2.getText());
        marks[2] = Integer.parseInt(jtxtScore3.getText());
        marks[3] = Integer.parseInt(jtxtScore4.getText());
        marks[4] = Integer.parseInt(jtxtScore5.getText());

        marks[5] = marks[0]+ marks[1] + marks[2] + marks[3] + marks[4];
        jtxtTotalScore.setText(Integer.toString(marks[5]));

        if(marks[5]>= 500)
        {
            jtxtRanking.setText("1st Group");
        }
        else if(marks[5]>= 400)
        {
            jtxtRanking.setText("2nd Group");
        }
        else if(marks[5]>= 300)
        {
            jtxtRanking.setText("3rd Group");
        }
        else if(marks[5]>= 200)
        {
            jtxtRanking.setText("4th Group");
        }
        else
        {
            jtxtRanking.setText("Fail");
        }
        /////// make text field 0 if the value is greater than 100//////
        if(marks[0]>100)
        {
            jtxtScore1.setText("0");
        }
        if(marks[1]>100)
        {
            jtxtScore2.setText("0");
        }
        if(marks[2]>100)
        {
            jtxtScore3.setText("0");
        }
        if(marks[3]>100)
        {
            jtxtScore4.setText("0");
        }
        if(marks[4]>100)
        {
            jtxtScore5.setText("0");
        }
        
        //////////////////////////////////////////////////////////////////////
        ///////////////set date from calendar to tex field/////////////////
        Date date = jCalendar1.getDate();
        DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
        String strDate = df.format(date);
        jtxtDate.setText(strDate);
    }//GEN-LAST:event_jbResultActionPerformed

    private void jbResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbResetActionPerformed

        jtxtStudentID.setText(null);
        jtxtFirstname.setText(null);
        jtxtSurname.setText(null);
        jtxtAddress.setText(null);
        jcboGender.setSelectedIndex(0);
        jtxtAge.setText(null);
        jtxtPhoneNumber.setText(null);
        jtxtEmail.setText(null);
        jcboHS.setSelectedIndex(0);
        jcboExchange.setSelectedIndex(0);
        jcboAccom.setSelectedIndex(0);
        
        jcboDegre.setSelectedIndex(0);
        jtxtFacultyName.setText(null);
        jcboBSc.setSelectedIndex(0);
        jcboMSc.setSelectedIndex(0);
        jtxtDoF.setText(null);
        jtxtDeputyDean.setText(null);
        jtxtHoD.setText(null);
        jcboScholarship.setSelectedIndex(0);

        jcboClass1.setSelectedIndex(0);
        jtxtScore1.setText(null);
        jcboClass2.setSelectedIndex(0);
        jtxtScore2.setText(null);
        jcboClass3.setSelectedIndex(0);
        jtxtScore3.setText(null);
        jcboClass4.setSelectedIndex(0);
        jtxtScore4.setText(null);
        jcboClass5.setSelectedIndex(0);
        jtxtScore5.setText(null);
        
        jtxtTotalScore.setText(null);
        jtxtRanking.setText(null);
        jtxtDate.setText(null);

    }//GEN-LAST:event_jbResetActionPerformed

    private void jbAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAddActionPerformed
        try
        {
            DBConnection.connect();
            pst = sqlCon.prepareStatement("insert into stdb (StudentID,Firstname,"
                +"Surname,Address,Gender,Age,PhoneNumber,Email,Degre,HomeStudent,"
                +"Accommodation,Exchange,Scholarship,BSc,MSc,Class1,Score1,"
                +"Class2,Score2,Class3,Score3,Class4,Score4,Class5,Score5,TotalScore,Ranking,Date)"
                +"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
             
            
            pst.setString(1,jtxtStudentID.getText());
            pst.setString(2,jtxtFirstname.getText());
            pst.setString(3,jtxtSurname.getText());
            pst.setString(4,jtxtAddress.getText());
            pst.setString(5,(String)jcboGender.getSelectedItem());
            pst.setString(6,jtxtAge.getText());
            pst.setString(7,jtxtPhoneNumber.getText());
            pst.setString(8,jtxtEmail.getText());
            pst.setString(9,(String)jcboDegre.getSelectedItem());
            pst.setString(10,(String)jcboHS.getSelectedItem());
            pst.setString(11,(String)jcboAccom.getSelectedItem());
            pst.setString(12,(String)jcboExchange.getSelectedItem());
            
            pst.setString(13,(String)jcboScholarship.getSelectedItem());
            pst.setString(14,(String)jcboBSc.getSelectedItem());
            pst.setString(15,(String)jcboMSc.getSelectedItem());
            pst.setString(16,(String)jcboClass1.getSelectedItem());
            pst.setString(17,jtxtScore1.getText());
            pst.setString(18,(String)jcboClass2.getSelectedItem());
            pst.setString(19,jtxtScore2.getText());
            pst.setString(20,(String)jcboClass3.getSelectedItem());
  
            pst.setString(21,jtxtScore3.getText());
            pst.setString(22,(String)jcboClass4.getSelectedItem());
            pst.setString(23,jtxtScore4.getText());
            pst.setString(24,(String)jcboClass5.getSelectedItem());
            pst.setString(25,jtxtScore5.getText());
            pst.setString(26,jtxtTotalScore.getText());
            pst.setString(27,jtxtRanking.getText());
            pst.setString(28,jtxtDate.getText());

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "You have added another student");
            uploadDBtable();
        }
        catch(SQLException ex)
        {
            java.util.logging.Logger.getLogger(Student_MS.class.getName()).log(java.util.logging.Level.SEVERE,null, ex);
        }
    }//GEN-LAST:event_jbAddActionPerformed

    private void jcboClass2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcboClass2ActionPerformed
        if(jcboClass2.getSelectedItem().equals(""))
        {
            jtxtScore2.setText("0");
            jtxtScore2.setEditable(false);
        }else{
            jtxtScore2.setText("");
            jtxtScore2.setEditable(true);
            jtxtScore2.requestFocus();
        }
    }//GEN-LAST:event_jcboClass2ActionPerformed

    private void jcboClass1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcboClass1ActionPerformed

        if(jcboClass1.getSelectedItem().equals(""))
        {
            jtxtScore1.setText("0");
            jtxtScore1.setEditable(false);
        }else{
            jtxtScore1.setText("");
            jtxtScore1.setEditable(true);
            jtxtScore1.requestFocus();
        }
    }//GEN-LAST:event_jcboClass1ActionPerformed

    private void jcboClass5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcboClass5ActionPerformed
        if(jcboClass5.getSelectedItem().equals(""))
        {
            jtxtScore5.setText("0");
            jtxtScore5.setEditable(false);
        }else{
            jtxtScore5.setText("");
            jtxtScore5.setEditable(true);
            jtxtScore5.requestFocus();
        }
    }//GEN-LAST:event_jcboClass5ActionPerformed

    private void jcboClass4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcboClass4ActionPerformed
        if(jcboClass4.getSelectedItem().equals(""))
        {
            jtxtScore4.setText("0");
            jtxtScore4.setEditable(false);
        }else{
            jtxtScore4.setText("");
            jtxtScore4.setEditable(true);
            jtxtScore4.requestFocus();
        }
    }//GEN-LAST:event_jcboClass4ActionPerformed

    private void jcboClass3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcboClass3ActionPerformed
        if(jcboClass3.getSelectedItem().equals(""))
        {
            jtxtScore3.setText("0");
            jtxtScore3.setEditable(false);
        }else{
            jtxtScore3.setText("");
            jtxtScore3.setEditable(true);
            jtxtScore3.requestFocus();
        }
    }//GEN-LAST:event_jcboClass3ActionPerformed

    private void jcboDegreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcboDegreActionPerformed

        if(jcboDegre.getSelectedItem().equals("Software Engineering"))
        {
            jtxtFacultyName.setText("Faculty of Engineering");
            jtxtFacultyName.setEditable(false);
            jtxtDoF.setText("Prof.Dr.Margarita Ifti");
            jtxtDoF.setEditable(false);
            jtxtDeputyDean.setText("Prof.Dr.Özcan Asilkan");
            jtxtDeputyDean.setEditable(false);
            jtxtHoD.setText("PhD. Adriola Faqolli");
            jtxtHoD.setEditable(false);
        }
        if(jcboDegre.getSelectedItem().equals("Computer Engineering & IT"))
        {
            jtxtFacultyName.setText("Faculty of Engineering");
            jtxtFacultyName.setEditable(false);
            jtxtDoF.setText("Prof.Dr.Margarita Ifti");
            jtxtDoF.setEditable(false);
            jtxtDeputyDean.setText("Prof.Dr.Özcan Asilkan");
            jtxtDeputyDean.setEditable(false);
            jtxtHoD.setText("PhD. Adriola Faqolli");
            jtxtHoD.setEditable(false);
        }
        if(jcboDegre.getSelectedItem().equals("Telecommunication Engineering"))
        {
            jtxtFacultyName.setText("Faculty of Engineering");
            jtxtFacultyName.setEditable(false);
            jtxtDoF.setText("Prof.Dr.Margarita Ifti");
            jtxtDoF.setEditable(false);
            jtxtDeputyDean.setText("Prof.Dr.Özcan Asilkan");
            jtxtDeputyDean.setEditable(false);
            jtxtHoD.setText("PhD.Donald Elmazi");
            jtxtHoD.setEditable(false);
        }
        if(jcboDegre.getSelectedItem().equals("Business Administration"))
        {
            jtxtFacultyName.setText("Faculty of Economy");
             jtxtFacultyName.setEditable(false);
            jtxtDoF.setText("Assoc.Prof.Altin Hoti");
            jtxtDoF.setEditable(false);
            jtxtDeputyDean.setText("PhD.Edmira Cakrani");
            jtxtDeputyDean.setEditable(false);
            jtxtHoD.setText("Dr.Eugen Musta");
            jtxtHoD.setEditable(false);
        }
        if(jcboDegre.getSelectedItem().equals("Business Administration & IT"))
        {
           jtxtFacultyName.setText("Faculty of Economy");
             jtxtFacultyName.setEditable(false);
            jtxtDoF.setText("Assoc.Prof.Altin Hoti");
            jtxtDoF.setEditable(false);
            jtxtDeputyDean.setText("PhD.Edmira Cakrani");
            jtxtDeputyDean.setEditable(false);
            jtxtHoD.setText("PhD.Blendi Shima");
            jtxtHoD.setEditable(false);
        }
        if(jcboDegre.getSelectedItem().equals("Finance & Accounting"))
        {
            jtxtFacultyName.setText("Faculty of Economy");
             jtxtFacultyName.setEditable(false);
            jtxtDoF.setText("Assoc.Prof.Altin Hoti");
            jtxtDoF.setEditable(false);
            jtxtDeputyDean.setText("PhD.Edmira Cakrani");
            jtxtDeputyDean.setEditable(false);
            jtxtHoD.setText("Dr.Eugen Musta");
            jtxtHoD.setEditable(false);
        }
    }//GEN-LAST:event_jcboDegreActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Student_MS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Student_MS().setVisible(true);
        });
    }
//Declaration of all components
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLAddr;
    private javax.swing.JLabel jLAge;
    private javax.swing.JLabel jLEmail;
    private javax.swing.JLabel jLFname;
    private javax.swing.JLabel jLGen;
    private javax.swing.JLabel jLMyName;
    private javax.swing.JLabel jLPh_num;
    private javax.swing.JLabel jLSname;
    private javax.swing.JLabel jLStdID;
    private javax.swing.JLabel jLTitle2;
    private javax.swing.JLabel jLTitle3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JPanel jPanButtons;
    private javax.swing.JPanel jPanCla_Sco;
    private javax.swing.JPanel jPanDB;
    private javax.swing.JPanel jPanDegre;
    private javax.swing.JPanel jPanMain;
    private javax.swing.JPanel jPanStudent;
    private javax.swing.JPanel jPanTableDB;
    private javax.swing.JPanel jPanTitle;
    private javax.swing.JPanel jPanTitle1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabSelect;
    private javax.swing.JTable jTableDB;
    private javax.swing.JButton jbAdd;
    private javax.swing.JButton jbExit;
    private javax.swing.JButton jbReset;
    private javax.swing.JButton jbResult;
    private javax.swing.JComboBox<String> jcboAccom;
    private javax.swing.JComboBox<String> jcboBSc;
    private javax.swing.JComboBox<String> jcboClass1;
    private javax.swing.JComboBox<String> jcboClass2;
    private javax.swing.JComboBox<String> jcboClass3;
    private javax.swing.JComboBox<String> jcboClass4;
    private javax.swing.JComboBox<String> jcboClass5;
    private javax.swing.JComboBox<String> jcboDegre;
    private javax.swing.JComboBox<String> jcboExchange;
    private javax.swing.JComboBox<String> jcboGender;
    private javax.swing.JComboBox<String> jcboHS;
    private javax.swing.JComboBox<String> jcboMSc;
    private javax.swing.JComboBox<String> jcboScholarship;
    private javax.swing.JTextField jtxtAddress;
    private javax.swing.JTextField jtxtAge;
    private javax.swing.JTextField jtxtDate;
    private javax.swing.JTextField jtxtDeputyDean;
    private javax.swing.JTextField jtxtDoF;
    private javax.swing.JTextField jtxtEmail;
    private javax.swing.JTextField jtxtFacultyName;
    private javax.swing.JTextField jtxtFirstname;
    private javax.swing.JTextField jtxtHoD;
    private javax.swing.JTextField jtxtPhoneNumber;
    private javax.swing.JTextField jtxtRanking;
    private javax.swing.JTextField jtxtScore1;
    private javax.swing.JTextField jtxtScore2;
    private javax.swing.JTextField jtxtScore3;
    private javax.swing.JTextField jtxtScore4;
    private javax.swing.JTextField jtxtScore5;
    private javax.swing.JTextField jtxtStudentID;
    private javax.swing.JTextField jtxtSurname;
    private javax.swing.JTextField jtxtTotalScore;
    // End of variables declaration//GEN-END:variables
}